﻿# Tech Simpld - Home Lab Docker Compose Starter Pack (2026 Edition)
Official companion repository for Tech Simpld tutorials: https://techsimpld.com

## Included Stacks:
1. `obsidian-browser/`: Stream full desktop Obsidian inside any browser via KasmVNC.
2. `cloudflare-tunnel/`: Secure Zero Trust remote access without open ports.
3. `alexandrie-hub/`: Web-first self-hosted markdown knowledge base.
4. `pihole/`: Network-wide DNS ad blocking.
5. `portainer-watchtower/`: Visual container GUI management and automated updates.

## Quick Launch:
Navigate to any subfolder and run:
`docker compose up -d`
