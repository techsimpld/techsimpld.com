Move your processed daily notes, projects, and permanent notes into this folder for long-term storage.
